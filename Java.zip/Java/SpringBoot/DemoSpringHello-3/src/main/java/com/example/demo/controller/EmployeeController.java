package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.model.Employee;
import com.example.demo.service.EmployeeService;

@Controller
public class EmployeeController {
	@Autowired
	EmployeeService empService;
	 @RequestMapping("/addemployee")
    public String addEmp(Model m) {
        m.addAttribute("empBean", new Employee());
        return "emp";
    }
    
    @RequestMapping("/empSave")
    public String saveEmp(@ModelAttribute("empBean") Employee e)
{
    	empService.addEmployee(e);
    	return "success";
    	
    }
    @RequestMapping("/viewform")
    public String viewemp(Model M) {
    	List<Employee> list = empService.viewAll();
    	M.addAttribute("List",list);
    	return "view";
    }
}
