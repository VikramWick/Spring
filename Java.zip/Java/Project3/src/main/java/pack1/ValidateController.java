package pack1;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ValidateController {
	@RequestMapping("/validate")
	public String isValid(@RequestParam("username") String username, @RequestParam("password") String password,
			Model model) {
 
		if ("abc".equals(username) && "123".equals(password)) {
			model.addAttribute("username",username);
			return "success";
		} else {
			return "redirect:/error";
		}
	}
	
//	@RequestMapping("/success")
//	public String showSuccess() {
//	    return "success";
//	}
 
	@RequestMapping("/error")
	public String showError() {
	    return "error";
	}

}
