package Pack3;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
public class MultipleTrans {

	public static void main(String[] args) {
		Session session=null;
		 try
		    {
		 SessionFactory factory=HibernateUtil.getSessionFactory();
		  session=factory.openSession(); 
		   
		    Transaction tx=session.beginTransaction();
			 			 
			 Login obj=(Login) session.load(Login.class,3);
		 
			 obj.setPass("Britto");
			 session.update(obj);
			 tx.commit();
			 tx=null;
			 session.close();
			 
				
				  System.out.println("Login Object now detatched"); //Reattach and update
				  
				  
				  session=factory.openSession();
				   tx=session.beginTransaction();
				  obj.setPass("sindhu"); 
				  session.update(obj);
				  tx.commit();
				 
				  System.out.println("Login object synchronized again");
				 
			 
		  }catch(Exception e){
			  System.out.println("exc "+e.getMessage());
			}finally{
				  session.close();
			 
			  }
	}
	
	}
