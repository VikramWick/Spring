package pack1;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class ServletDemo
 */
@WebServlet(urlPatterns = {"/ServletDemo","/admin/sec.view"})

public class ServletDemo extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ServletContext ctx;
	RequestDispatcher rd=null;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletDemo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String u=request.getParameter("user");
		String p=request.getParameter("pass");
		ctx=getServletContext();
		if(u.equals("admin") && p.equals("abc"))
		{
//			rd=ctx.getRequestDispatcher("/pages/success.html");
//			rd.forward(request, response);
			response.sendRedirect("https://www.geeksforgeeks.org/hashtable-in-java/");
//			out.println(u+" "+p);
		}
//		else 
//		{
//			rd=ctx.getRequestDispatcher("/log.html");
//			rd.include(request, response);
//			out.println("<font color=red> Wrong Username or Password</font>");
//		}
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
