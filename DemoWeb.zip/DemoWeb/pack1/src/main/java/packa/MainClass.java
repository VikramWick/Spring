package packa;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class MainClass {
public static void main(String args[]) {
	 ApplicationContext ac = new ClassPathXmlApplicationContext("Spring.xml");
    
    PersonDAO acct = (PersonDAO)ac.getBean("PersonDAO");
    Person p = new Person();
    acct.save(p);
    for(Person a :acct.list()){
   	 System.out.println(a.getId());
   	 System.out.println(a.getName());
   
    }
}
}
