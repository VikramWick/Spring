package com.example.demo;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import org.springframework.stereotype.Service;

@Service
public class ProductService {
	Set<Product> products=new HashSet<Product>();
	ProductService(){
		products.add(new Product(56,"Bolts","B des",4500,"abc","a@yahoo.com"));
		products.add(new Product(34,"nuts","C des",6000,"xyz","b@yahoo.com"));
	}
	public Set<Product> getProducts(){
		return products;
	}
	public Product getProductById(int id) {
		Product prod=products.stream().filter(p->p.getId()==id).findAny().orElse(null);
		return prod;
	}
	public Product addProduct(Product prod) {
		Random r=new Random();
		prod.setId(r.nextInt(200));
		products.add(prod);
		return prod;
	}
	public void removeProduct(Product prod) {
		products.remove(prod);
	}
}